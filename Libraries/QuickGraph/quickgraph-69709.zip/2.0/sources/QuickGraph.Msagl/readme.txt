﻿To build this project, you will need a copy of MSAGL

	http://research.microsoft.com/research/msagl/
	