import clr
clr.AddReferenceToFile("QuickGraph.Heap")
import QuickGraph.Heap
from QuickGraph.Heap import GcTypeHeap
