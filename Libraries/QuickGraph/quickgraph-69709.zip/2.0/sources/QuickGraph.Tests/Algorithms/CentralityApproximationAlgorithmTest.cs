﻿using System;
using QuickGraph.Unit;

namespace QuickGraph.Algorithms
{
    [TestFixture]
    public class CentralityApproximationAlgorithmTest
    {
    }
}
