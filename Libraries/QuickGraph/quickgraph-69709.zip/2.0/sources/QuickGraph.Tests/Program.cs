using System;
using System.Collections.Generic;
using System.Text;
using QuickGraph.Unit;

namespace QuickGraph.Tests
{
    class Program
    {
        static int Main(string[] args)
        {
            return TestRunner.TestMain(args);
        }
    }
}
