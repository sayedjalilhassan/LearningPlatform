﻿using System;

namespace QuickGraph
{
    [Serializable]
    public enum GraphColor
    {
        White,
        Gray,
        Black
    }
}
