﻿namespace QuickGraph.Algorithms.Services
{
    public interface IService
    {}
}
