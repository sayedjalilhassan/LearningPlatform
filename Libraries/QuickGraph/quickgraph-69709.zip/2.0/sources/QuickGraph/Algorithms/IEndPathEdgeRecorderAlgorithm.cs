﻿using System;
namespace QuickGraph.Algorithms
{
    public interface IEndPathEdgeRecorderAlgorithm<TVertex,TEdge>
        where TEdge : IEdge<TVertex>
    {
    }
}
