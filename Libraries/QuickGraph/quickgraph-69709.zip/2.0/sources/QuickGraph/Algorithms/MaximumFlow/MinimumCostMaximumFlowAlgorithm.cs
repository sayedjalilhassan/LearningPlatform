﻿using System;

namespace QuickGraph.Algorithms.MaximumFlow
{
    public class MinimumCostMaximumFlowAlgorithm
    {
        public MinimumCostMaximumFlowAlgorithm()
        {

        }
    }
}
