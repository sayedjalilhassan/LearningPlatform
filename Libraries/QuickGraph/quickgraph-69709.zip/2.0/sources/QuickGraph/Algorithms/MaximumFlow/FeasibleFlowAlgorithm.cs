﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace QuickGraph.Algorithms.MaximumFlow
{
    public class FeasibleFlowAlgorithm
    {
        public FeasibleFlowAlgorithm()
        {

        }
    }
}
