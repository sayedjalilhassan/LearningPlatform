namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizArrowShape
    {
        Box,
        Crow,
        Diamond,
        Dot,
        Inv,
        None,
        Normal,
        Tee,
        Vee
    }
}

