namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizEdgeStyle
    {
        Unspecified,
        Invis,
        Dashed,
        Dotted,
        Bold,
        Solid
    }
}

