namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizRankDirection
    {
        LR,
        TB
    }
}

