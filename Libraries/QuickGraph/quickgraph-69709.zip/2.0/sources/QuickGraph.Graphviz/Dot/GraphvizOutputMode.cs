namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizOutputMode
    {
        BreadthFirst,
        NodesFirst,
        EdgesFirst
    }
}

