namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizEdgeDirection
    {
        None,
        Forward,
        Back,
        Both
    }
}

