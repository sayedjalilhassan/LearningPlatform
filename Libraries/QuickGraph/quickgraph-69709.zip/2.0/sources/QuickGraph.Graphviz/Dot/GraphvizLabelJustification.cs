namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizLabelJustification
    {
        L,
        R,
        C
    }
}

