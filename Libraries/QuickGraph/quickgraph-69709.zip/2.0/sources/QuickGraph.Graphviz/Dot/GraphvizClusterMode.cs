namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizClusterMode
    {
        Local,
        Global,
        None
    }
}

