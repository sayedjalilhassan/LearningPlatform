namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizRatioMode
    {
        Fill,
        Compress,
        Auto
    }
}

