namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizArrowFilling
    {
        Close,
        Open
    }
}

