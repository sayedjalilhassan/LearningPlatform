namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizLabelLocation
    {
        T,
        B
    }
}

