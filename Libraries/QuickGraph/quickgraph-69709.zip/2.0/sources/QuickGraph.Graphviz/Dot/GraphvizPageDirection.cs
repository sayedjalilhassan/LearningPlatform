namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizPageDirection
    {
        BL,
        BR,
        TL,
        TR,
        RB,
        RT,
        LB,
        LT
    }
}

