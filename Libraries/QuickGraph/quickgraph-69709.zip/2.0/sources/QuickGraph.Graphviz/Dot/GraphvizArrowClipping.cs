namespace QuickGraph.Graphviz.Dot
{
    using System;

    public enum GraphvizArrowClipping
    {
        None,
        Left,
        Right
    }
}

