﻿using System;
using System.Collections.Generic;

namespace QuickGraph.Unit.Serialization
{
    [Serializable]
    public sealed class XmlTestCaseCollection : List<XmlTestCase>
    {
        public XmlTestCaseCollection() { }
    }
}
