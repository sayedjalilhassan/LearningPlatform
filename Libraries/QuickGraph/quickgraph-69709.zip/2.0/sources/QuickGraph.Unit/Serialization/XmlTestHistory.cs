using System;

namespace QuickGraph.Unit
{
    public enum XmlTestHistory
    {
        NoChange,
        New,
        Fixed,
        Failure
    }
}
