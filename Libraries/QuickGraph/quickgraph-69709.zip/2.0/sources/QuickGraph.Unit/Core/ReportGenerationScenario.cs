﻿namespace QuickGraph.Unit.Core
{
    public enum ReportGenerationScenario
    {
        None,
        OnFailure,
        Always
    }
}
