﻿namespace QuickGraph.Unit.Core
{
    public enum TestState :short
    {
        NotRun = 0,
        Success = 1,
        Ignore = 2,
        Failure = 3
    }
}
