﻿using System;

namespace QuickGraph.Operations
{
    public enum CombinationType
    {
        PairWize,
        Cartesian
    }
}
