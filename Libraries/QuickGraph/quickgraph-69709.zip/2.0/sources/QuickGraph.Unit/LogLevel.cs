﻿using System;
namespace QuickGraph.Unit
{
    public enum LogLevel
    {
        Message,
        Warning,
        Error
    }
}
