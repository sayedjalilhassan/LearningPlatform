using System;

namespace QuickGraph.Unit
{
    [Serializable]
    public enum MessageImportance
    {
        Low,
        Normal,
        High
    }
}
